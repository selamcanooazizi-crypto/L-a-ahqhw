package com.pikachuclient.module.misc;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.NumberSetting;

public class SwingSpeedModule extends Module {
    public final NumberSetting duration = add(new NumberSetting("Swing Ticks", 6, 1, 20, 1));

    public SwingSpeedModule() {
        super("Swing Speed", "Changes how long your hand swing lasts.", Category.COMBAT);
    }
}
