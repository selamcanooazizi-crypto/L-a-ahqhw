package com.pikachuclient.module.misc;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;

public class ScoreboardToggleModule extends Module {
    public ScoreboardToggleModule() {
        super("Hide Scoreboard", "Hides the sidebar scoreboard while enabled.", Category.MISC);
    }
}
