package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.NumberSetting;

public class ViewModelModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 0.0, -1.0, 1.0, 0.05));
    public final NumberSetting y = add(new NumberSetting("Y", 0.0, -1.0, 1.0, 0.05));
    public final NumberSetting z = add(new NumberSetting("Z", 0.0, -1.0, 1.0, 0.05));
    public final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.1, 2.0, 0.05));

    public ViewModelModule() {
        super("View Model", "Moves and scales the item in your hand.", Category.RENDER);
    }
}
