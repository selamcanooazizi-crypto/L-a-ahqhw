package com.pikachuclient.module.hud;

import net.minecraft.client.MinecraftClient;

import java.util.Locale;

public class CoordsModule extends TextHudModule {
    public CoordsModule() {
        super("Coords", "Shows your coordinates.");
    }

    @Override
    protected String text(MinecraftClient mc) {
        if (mc.player == null) {
            return null;
        }
        return String.format(Locale.ROOT, "XYZ: %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
    }
}
