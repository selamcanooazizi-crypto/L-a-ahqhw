package com.pikachuclient.module;

public enum Category {
    HUD("HUD"),
    RENDER("Render"),
    MOVEMENT("Movement"),
    COMBAT("Combat"),
    WORLD("World"),
    MISC("Misc");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
