package com.pikachuclient.module.hud;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.BooleanSetting;
import com.pikachuclient.module.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class TextHudModule extends Module {
    public final ColorSetting color = add(new ColorSetting("Color", 0xFFFFFF));
    public final BooleanSetting shadow = add(new BooleanSetting("Shadow", true));

    protected TextHudModule(String name, String description) {
        super(name, description, Category.HUD);
    }

    protected abstract String text(MinecraftClient mc);

    @Override
    public int renderHud(DrawContext context, MinecraftClient mc, int y) {
        String t = text(mc);
        if (t == null) {
            return y;
        }
        context.drawText(mc.textRenderer, t, 4, y, color.argb(), shadow.get());
        return y + 11;
    }
}
