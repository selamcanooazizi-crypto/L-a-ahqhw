package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.NumberSetting;

import java.util.HashMap;
import java.util.Map;

public class ItemPhysicsModule extends Module {
    public final NumberSetting spin = add(new NumberSetting("Spin Speed", 1.0, 0.0, 3.0, 0.1));

    /** Per item data, keyed by the item's unique render offset. */
    public static final Map<Float, Data> DATA = new HashMap<>();

    public static class Data {
        public boolean onGround;
        public float rx;
        public float ry;
        public float rz;
        public float vx;
        public float vy;
        public float vz;
        public long lastNanos;
        public long lastSeenMs;
    }

    public ItemPhysicsModule() {
        super("Item Physics", "Dropped items tumble in the air and lie flat on the ground.", Category.RENDER);
    }

    @Override
    protected void onDisable() {
        DATA.clear();
    }

    public Data update(float key, boolean onGround) {
        Data d = DATA.get(key);
        long now = System.nanoTime();
        if (d == null) {
            d = new Data();
            java.util.Random rnd = new java.util.Random(Float.floatToIntBits(key));
            d.vx = (rnd.nextFloat() * 2f - 1f) * 9f + 4f;
            d.vy = (rnd.nextFloat() * 2f - 1f) * 9f;
            d.vz = (rnd.nextFloat() * 2f - 1f) * 9f + 4f;
            d.rx = rnd.nextFloat() * 360f;
            d.ry = rnd.nextFloat() * 360f;
            d.rz = rnd.nextFloat() * 360f;
            d.lastNanos = now;
            DATA.put(key, d);
        }
        float dt = Math.min(0.1f, (now - d.lastNanos) / 1.0e9f);
        d.lastNanos = now;
        d.lastSeenMs = System.currentTimeMillis();
        d.onGround = onGround;

        if (!onGround) {
            float s = spin.f() * dt * 60f;
            d.rx += d.vx * s * 0.25f;
            d.ry += d.vy * s * 0.25f;
            d.rz += d.vz * s * 0.25f;
        }

        if (DATA.size() > 256) {
            long cutoff = System.currentTimeMillis() - 5000;
            DATA.values().removeIf(v -> v.lastSeenMs < cutoff);
        }
        return d;
    }
}
