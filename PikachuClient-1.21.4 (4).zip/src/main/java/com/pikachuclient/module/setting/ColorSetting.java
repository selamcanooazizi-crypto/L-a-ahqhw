package com.pikachuclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** RGB color made of three 0-255 sliders. */
public class ColorSetting extends Setting<Integer> {
    public final NumberSetting r;
    public final NumberSetting g;
    public final NumberSetting b;

    public ColorSetting(String name, int rgb) {
        super(name, rgb & 0xFFFFFF);
        this.r = new NumberSetting("Red", (rgb >> 16) & 0xFF, 0, 255, 1);
        this.g = new NumberSetting("Green", (rgb >> 8) & 0xFF, 0, 255, 1);
        this.b = new NumberSetting("Blue", rgb & 0xFF, 0, 255, 1);
    }

    @Override
    public Integer get() {
        return (r.i() << 16) | (g.i() << 8) | b.i();
    }

    @Override
    public void set(Integer value) {
        r.set((double) ((value >> 16) & 0xFF));
        g.set((double) ((value >> 8) & 0xFF));
        b.set((double) (value & 0xFF));
    }

    /** Opaque ARGB value. */
    public int argb() {
        return 0xFF000000 | get();
    }

    /** ARGB value with the given alpha (0-255). */
    public int argb(int alpha) {
        return ((alpha & 0xFF) << 24) | get();
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(get());
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive()) {
            set(element.getAsInt());
        }
    }
}
