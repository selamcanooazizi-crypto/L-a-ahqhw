package com.pikachuclient.module.render;

import com.pikachuclient.mixin.SimpleOptionAccessor;
import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import net.minecraft.client.MinecraftClient;

public class FullbrightModule extends Module {
    private double previous = 1.0;

    public FullbrightModule() {
        super("Fullbright", "Maximum brightness everywhere.", Category.RENDER);
    }

    @Override
    protected void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.options != null) {
            Double v = mc.options.getGamma().getValue();
            previous = v == null ? 1.0 : Math.min(v, 1.0);
        }
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ((SimpleOptionAccessor) (Object) mc.options.getGamma()).pikachu$setRaw(16.0);
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.options != null) {
            ((SimpleOptionAccessor) (Object) mc.options.getGamma()).pikachu$setRaw(previous);
        }
    }
}
