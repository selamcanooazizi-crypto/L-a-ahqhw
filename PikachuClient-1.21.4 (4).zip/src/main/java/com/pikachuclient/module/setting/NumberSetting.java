package com.pikachuclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumberSetting extends Setting<Double> {
    public final double min;
    public final double max;
    public final double step;

    public NumberSetting(String name, double value, double min, double max, double step) {
        super(name, value);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    @Override
    public void set(Double value) {
        this.value = Math.max(min, Math.min(max, value));
    }

    public void increase() {
        set(round(value + step));
    }

    public void decrease() {
        set(round(value - step));
    }

    private double round(double v) {
        return Math.round(v * 1000.0) / 1000.0;
    }

    public void setFraction(double fraction) {
        double f = Math.max(0.0, Math.min(1.0, fraction));
        double v = min + f * (max - min);
        v = Math.round(v / step) * step;
        set(round(v));
    }

    public double fraction() {
        return max == min ? 0.0 : (value - min) / (max - min);
    }

    public float f() {
        return value.floatValue();
    }

    public int i() {
        return (int) Math.round(value);
    }

    public String display() {
        if (step >= 1.0) {
            return String.valueOf(i());
        }
        return String.format(java.util.Locale.ROOT, "%.2f", value);
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value);
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive()) {
            set(element.getAsDouble());
        }
    }
}
