package com.pikachuclient.mixin;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.render.LowFireModule;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private static void pikachu$noFire(CallbackInfo ci) {
        if (PikachuClient.modules == null) {
            return;
        }
        LowFireModule m = PikachuClient.modules.get(LowFireModule.class);
        if (m != null && m.isEnabled()) {
            ci.cancel();
        }
    }
}
