package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;

public class LowFireModule extends Module {
    public LowFireModule() {
        super("No Fire Overlay", "Hides the fire overlay on your screen.", Category.RENDER);
    }
}
