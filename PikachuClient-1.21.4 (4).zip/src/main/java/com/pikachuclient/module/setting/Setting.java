package com.pikachuclient.module.setting;

import com.google.gson.JsonElement;

public abstract class Setting<T> {
    public final String name;
    protected T value;

    protected Setting(String name, T value) {
        this.name = name;
        this.value = value;
    }

    public T get() {
        return value;
    }

    public abstract void set(T value);

    public abstract JsonElement toJson();

    public abstract void fromJson(JsonElement element);
}
