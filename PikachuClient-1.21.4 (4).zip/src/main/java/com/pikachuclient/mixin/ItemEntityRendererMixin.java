package com.pikachuclient.mixin;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.render.ItemPhysicsModule;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V",
            at = @At("RETURN"))
    private void pikachu$track(ItemEntity entity, ItemEntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (PikachuClient.modules == null) {
            return;
        }
        ItemPhysicsModule m = PikachuClient.modules.get(ItemPhysicsModule.class);
        if (m != null && m.isEnabled()) {
            m.update(state.uniqueOffset, entity.isOnGround());
        }
    }

    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"), cancellable = true)
    private void pikachu$render(ItemEntityRenderState state, MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                int light, CallbackInfo ci) {
        if (PikachuClient.modules == null) {
            return;
        }
        ItemPhysicsModule m = PikachuClient.modules.get(ItemPhysicsModule.class);
        if (m == null || !m.isEnabled()) {
            return;
        }
        ci.cancel();
        if (state.itemRenderState.isEmpty()) {
            return;
        }
        ItemPhysicsModule.Data d = ItemPhysicsModule.DATA.get(state.uniqueOffset);
        boolean ground = d == null || d.onGround;

        matrices.push();
        if (ground) {
            matrices.translate(0.0F, 0.06F, 0.0F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(state.uniqueOffset * 57.29578F));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0F));
        } else {
            matrices.translate(0.0F, 0.25F, 0.0F);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(d.rx));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(d.ry));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(d.rz));
        }
        state.itemRenderState.render(matrices, vertexConsumers, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
    }
}
