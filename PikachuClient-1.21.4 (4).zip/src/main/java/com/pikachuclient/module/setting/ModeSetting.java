package com.pikachuclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class ModeSetting extends Setting<String> {
    public final String[] modes;

    public ModeSetting(String name, String value, String... modes) {
        super(name, value);
        this.modes = modes;
    }

    @Override
    public void set(String value) {
        for (String m : modes) {
            if (m.equals(value)) {
                this.value = value;
                return;
            }
        }
    }

    public void cycle(int dir) {
        int idx = 0;
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equals(value)) {
                idx = i;
            }
        }
        idx = (idx + dir + modes.length) % modes.length;
        this.value = modes[idx];
    }

    public boolean is(String mode) {
        return value.equals(mode);
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value);
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive()) {
            set(element.getAsString());
        }
    }
}
