package com.pikachuclient.module.misc;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import net.minecraft.client.MinecraftClient;

public class SprintModule extends Module {
    public SprintModule() {
        super("Sprint", "Sprints automatically while moving forward.", Category.MOVEMENT);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player == null) {
            return;
        }
        if (mc.options.forwardKey.isPressed()
                && !mc.player.isSneaking()
                && !mc.player.horizontalCollision
                && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
