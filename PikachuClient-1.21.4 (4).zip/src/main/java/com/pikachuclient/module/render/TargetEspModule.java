package com.pikachuclient.module.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.ColorSetting;
import com.pikachuclient.module.setting.ModeSetting;
import com.pikachuclient.module.setting.NumberSetting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class TargetEspModule extends Module {
    private static final Identifier ORB = Identifier.of("pikachuclient", "textures/targetesp/orb.png");
    private static final Identifier[] MARKERS = {
            Identifier.of("pikachuclient", "textures/targetesp/marker0.png"),
            Identifier.of("pikachuclient", "textures/targetesp/marker1.png"),
            Identifier.of("pikachuclient", "textures/targetesp/marker2.png"),
            Identifier.of("pikachuclient", "textures/targetesp/marker3.png")
    };

    public final ModeSetting mode = add(new ModeSetting("Mode", "Marker", "Marker", "Spiral Orb", "Ghost"));
    public final ModeSetting markerType = add(new ModeSetting("Marker Type", "Marker", "Marker", "Marker1", "Marker2", "Marker3"));
    public final ColorSetting color = add(new ColorSetting("Color", 0xFF4D4D));
    public final NumberSetting size = add(new NumberSetting("Size", 1.0, 0.3, 2.5, 0.1));

    private LivingEntity lastHit;
    private long lastHitMs;

    public TargetEspModule() {
        super("Target ESP", "Draws an effect on the player you are fighting.", Category.RENDER);
    }

    public void setLastHit(LivingEntity entity) {
        this.lastHit = entity;
        this.lastHitMs = System.currentTimeMillis();
    }

    private LivingEntity findTarget(MinecraftClient mc) {
        Entity looked = mc.targetedEntity;
        if (looked instanceof LivingEntity living && living != mc.player && living.isAlive()
                && mc.player.distanceTo(living) <= 6.0F) {
            return living;
        }
        if (lastHit != null && lastHit.isAlive() && !lastHit.isRemoved()
                && System.currentTimeMillis() - lastHitMs < 3000) {
            return lastHit;
        }
        return null;
    }

    public void render(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || context.matrixStack() == null) {
            return;
        }
        LivingEntity target = findTarget(mc);
        if (target == null) {
            return;
        }

        float tickDelta = mc.getRenderTickCounter().getTickDelta(true);
        Camera camera = context.camera();
        Vec3d cam = camera.getPos();
        Vec3d p = target.getLerpedPos(tickDelta);
        float cx = (float) (p.x - cam.x);
        float cy = (float) (p.y - cam.y);
        float cz = (float) (p.z - cam.z);
        float h = target.getHeight();
        float w = target.getWidth();
        Matrix4f matrix = context.matrixStack().peek().getPositionMatrix();
        double t = (System.currentTimeMillis() % 1000000L) / 1000.0;

        Quaternionf rotation = camera.getRotation();
        Vector3f right = new Vector3f(1, 0, 0).rotate(rotation);
        Vector3f up = new Vector3f(0, 1, 0).rotate(rotation);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        if (mode.is("Marker")) {
            int idx = 0;
            for (int i = 0; i < markerType.modes.length; i++) {
                if (markerType.modes[i].equals(markerType.get())) {
                    idx = i;
                }
            }
            RenderSystem.setShaderTexture(0, MARKERS[idx]);
            float s = 0.55F * size.f() * (1.0F + 0.1F * (float) Math.sin(t * 4.0));
            quad(buffer, matrix, right, up, cx, cy + h * 0.5F, cz, s, (float) (t * 90.0), color.argb(210));
        } else if (mode.is("Spiral Orb")) {
            RenderSystem.setShaderTexture(0, ORB);
            int trail = 14;
            for (int strand = 0; strand < 2; strand++) {
                for (int i = 0; i < trail; i++) {
                    double f = t * 1.4 - i * 0.07;
                    double angle = f * Math.PI * 2.0 + strand * Math.PI;
                    float y = (float) ((Math.sin(f * 1.6) * 0.5 + 0.5) * h);
                    float radius = w * 0.9F + 0.25F;
                    float fade = 1.0F - (float) i / trail;
                    quad(buffer, matrix, right, up,
                            cx + (float) Math.cos(angle) * radius, cy + y, cz + (float) Math.sin(angle) * radius,
                            0.2F * size.f() * fade, 0.0F, color.argb((int) (230 * fade)));
                }
            }
        } else {
            RenderSystem.setShaderTexture(0, ORB);
            int trail = 10;
            for (int orb = 0; orb < 3; orb++) {
                float y = h * 0.5F + (float) Math.sin(t * 2.0 + orb) * h * 0.3F;
                for (int i = 0; i < trail; i++) {
                    double angle = t * 2.5 + orb * Math.PI * 2.0 / 3.0 - i * 0.12;
                    float radius = w * 0.9F + 0.3F;
                    float fade = 1.0F - (float) i / trail;
                    quad(buffer, matrix, right, up,
                            cx + (float) Math.cos(angle) * radius, cy + y, cz + (float) Math.sin(angle) * radius,
                            0.22F * size.f() * fade, 0.0F, color.argb((int) (230 * fade)));
                }
            }
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void quad(BufferBuilder b, Matrix4f m, Vector3f right, Vector3f up,
                             float x, float y, float z, float size, float rollDeg, int argb) {
        float rad = (float) Math.toRadians(rollDeg);
        float cos = (float) Math.cos(rad);
        float sin = (float) Math.sin(rad);
        float rx = (right.x * cos + up.x * sin) * size;
        float ry = (right.y * cos + up.y * sin) * size;
        float rz = (right.z * cos + up.z * sin) * size;
        float ux = (up.x * cos - right.x * sin) * size;
        float uy = (up.y * cos - right.y * sin) * size;
        float uz = (up.z * cos - right.z * sin) * size;

        b.vertex(m, x - rx - ux, y - ry - uy, z - rz - uz).texture(0.0F, 1.0F).color(argb);
        b.vertex(m, x + rx - ux, y + ry - uy, z + rz - uz).texture(1.0F, 1.0F).color(argb);
        b.vertex(m, x + rx + ux, y + ry + uy, z + rz + uz).texture(1.0F, 0.0F).color(argb);
        b.vertex(m, x - rx + ux, y - ry + uy, z - rz + uz).texture(0.0F, 0.0F).color(argb);
    }
}
