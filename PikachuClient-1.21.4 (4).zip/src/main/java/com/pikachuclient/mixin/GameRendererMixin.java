package com.pikachuclient.mixin;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.render.AspectRatioModule;
import com.pikachuclient.module.render.NoHurtCamModule;
import net.minecraft.client.render.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Shadow
    public abstract float getFarPlaneDistance();

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void pikachu$noHurtCam(CallbackInfo ci) {
        if (PikachuClient.modules == null) {
            return;
        }
        NoHurtCamModule m = PikachuClient.modules.get(NoHurtCamModule.class);
        if (m != null && m.isEnabled()) {
            ci.cancel();
        }
    }

    @Inject(method = "getBasicProjectionMatrix", at = @At("HEAD"), cancellable = true)
    private void pikachu$aspectRatio(float fovDegrees, CallbackInfoReturnable<Matrix4f> cir) {
        if (PikachuClient.modules == null) {
            return;
        }
        AspectRatioModule m = PikachuClient.modules.get(AspectRatioModule.class);
        if (m != null && m.isEnabled()) {
            Matrix4f matrix = new Matrix4f();
            matrix.perspective(fovDegrees * (float) (Math.PI / 180.0), m.ratio.f(), 0.05F, getFarPlaneDistance());
            cir.setReturnValue(matrix);
        }
    }
}
