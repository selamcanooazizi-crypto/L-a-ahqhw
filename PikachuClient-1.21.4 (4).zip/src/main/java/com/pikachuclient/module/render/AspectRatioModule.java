package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.NumberSetting;

public class AspectRatioModule extends Module {
    public final NumberSetting ratio = add(new NumberSetting("Ratio", 1.4, 0.5, 2.0, 0.01));

    public AspectRatioModule() {
        super("Aspect Ratio", "Stretches or squeezes the game picture.", Category.RENDER);
    }
}
