package com.pikachuclient.module.hud;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class CpsModule extends TextHudModule {
    private final List<Long> left = new ArrayList<>();
    private final List<Long> right = new ArrayList<>();
    private boolean leftDown;
    private boolean rightDown;

    public CpsModule() {
        super("CPS", "Shows your clicks per second.");
    }

    @Override
    protected String text(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        long now = System.currentTimeMillis();

        boolean l = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !leftDown) {
            left.add(now);
        }
        if (r && !rightDown) {
            right.add(now);
        }
        leftDown = l;
        rightDown = r;
        left.removeIf(t -> now - t > 1000);
        right.removeIf(t -> now - t > 1000);

        return "CPS: " + left.size() + " | " + right.size();
    }
}
