package com.pikachuclient.gui;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.BooleanSetting;
import com.pikachuclient.module.setting.ColorSetting;
import com.pikachuclient.module.setting.ModeSetting;
import com.pikachuclient.module.setting.NumberSetting;
import com.pikachuclient.module.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClickGuiScreen extends Screen {
    private static final int COL_W = 130;
    private static final int ROW_H = 14;
    private static final int SET_H = 12;

    /** Clickable area. slider != null means the area is a draggable slider. */
    private record Hit(int x, int y, int w, int h, Runnable left, Runnable right, NumberSetting slider) {
    }

    private final List<Hit> hits = new ArrayList<>();
    private final Set<Module> expanded = new HashSet<>();
    private Hit dragging;

    public ClickGuiScreen() {
        super(Text.literal(""));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        hits.clear();

        int x = 10;
        for (Category category : Category.values()) {
            List<Module> list = new ArrayList<>();
            for (Module m : PikachuClient.modules.all()) {
                if (m.category == category) {
                    list.add(m);
                }
            }
            if (list.isEmpty()) {
                continue;
            }

            int y = 14;
            context.fill(x, y, x + COL_W, y + ROW_H, 0xDD1E1E2E);
            context.drawText(textRenderer, category.label, x + 4, y + 3, 0xFFFFD84D, false);
            y += ROW_H;

            for (Module m : list) {
                final Module module = m;
                boolean open = expanded.contains(m);
                context.fill(x, y, x + COL_W, y + ROW_H, m.isEnabled() ? 0xCC2E7D32 : 0xAA000000);
                context.drawText(textRenderer, m.name, x + 4, y + 3, 0xFFFFFFFF, false);
                context.drawText(textRenderer, open ? "-" : "+", x + COL_W - 10, y + 3, 0xFFAAAAAA, false);
                hits.add(new Hit(x, y, COL_W, ROW_H, module::toggle, () -> {
                    if (!expanded.remove(module)) {
                        expanded.add(module);
                    }
                }, null));
                y += ROW_H;

                if (open) {
                    if (m.settings.isEmpty()) {
                        context.fill(x, y, x + COL_W, y + SET_H, 0xAA101018);
                        context.drawText(textRenderer, trim(m.description), x + 6, y + 2, 0xFF8A8A99, false);
                        y += SET_H;
                    }
                    for (Setting<?> s : m.settings) {
                        y = renderSetting(context, s, x, y);
                    }
                }
            }
            x += COL_W + 6;
        }
    }

    private String trim(String text) {
        int max = (COL_W - 10) / 6;
        return text.length() > max ? text.substring(0, max - 1) + "." : text;
    }

    private int renderSetting(DrawContext context, Setting<?> s, int x, int y) {
        if (s instanceof BooleanSetting b) {
            context.fill(x, y, x + COL_W, y + SET_H, 0xAA101018);
            context.drawText(textRenderer, b.name + ": " + (b.get() ? "On" : "Off"),
                    x + 6, y + 2, b.get() ? 0xFF7CFC7C : 0xFFCCCCCC, false);
            hits.add(new Hit(x, y, COL_W, SET_H, b::toggle, b::toggle, null));
            return y + SET_H;
        }
        if (s instanceof NumberSetting n) {
            return slider(context, n, n.name, 0xFFFFFFFF, 0xAA3F51B5, x, y);
        }
        if (s instanceof ModeSetting mode) {
            context.fill(x, y, x + COL_W, y + SET_H, 0xAA101018);
            context.drawText(textRenderer, mode.name + ": " + mode.get(), x + 6, y + 2, 0xFFFFD84D, false);
            hits.add(new Hit(x, y, COL_W, SET_H, () -> mode.cycle(1), () -> mode.cycle(-1), null));
            return y + SET_H;
        }
        if (s instanceof ColorSetting c) {
            context.fill(x, y, x + COL_W, y + SET_H, 0xAA101018);
            context.drawText(textRenderer, c.name, x + 6, y + 2, 0xFFFFFFFF, false);
            context.fill(x + COL_W - 22, y + 2, x + COL_W - 6, y + SET_H - 2, c.argb());
            y += SET_H;
            y = slider(context, c.r, "Red", 0xFFFF6B6B, 0xAAB71C1C, x, y);
            y = slider(context, c.g, "Green", 0xFF7CFC7C, 0xAA1B5E20, x, y);
            y = slider(context, c.b, "Blue", 0xFF74B9FF, 0xAA0D47A1, x, y);
            return y;
        }
        return y;
    }

    private int slider(DrawContext context, NumberSetting n, String label, int textColor, int fillColor, int x, int y) {
        context.fill(x, y, x + COL_W, y + SET_H, 0xAA101018);
        int fill = (int) Math.round((COL_W - 8) * n.fraction());
        context.fill(x + 4, y + 1, x + 4 + fill, y + SET_H - 1, fillColor);
        context.drawText(textRenderer, label + ": " + n.display(), x + 8, y + 2, textColor, false);
        hits.add(new Hit(x + 4, y, COL_W - 8, SET_H, null, null, n));
        return y + SET_H;
    }

    private void applySlider(Hit hit, double mouseX) {
        double f = (mouseX - hit.x()) / (double) hit.w();
        hit.slider().setFraction(f);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mouseX >= h.x() && mouseX < h.x() + h.w() && mouseY >= h.y() && mouseY < h.y() + h.h()) {
                if (h.slider() != null) {
                    if (button == 0) {
                        dragging = h;
                        applySlider(h, mouseX);
                    }
                } else if (button == 0 && h.left() != null) {
                    h.left().run();
                } else if (button == 1 && h.right() != null) {
                    h.right().run();
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging != null && button == 0) {
            applySlider(dragging, mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        PikachuClient.modules.save();
    }
}
