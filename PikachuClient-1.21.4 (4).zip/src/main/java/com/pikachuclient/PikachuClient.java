package com.pikachuclient;

import com.pikachuclient.gui.ClickGuiScreen;
import com.pikachuclient.module.ModuleManager;
import com.pikachuclient.module.render.TargetEspModule;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class PikachuClient implements ClientModInitializer {
    public static ModuleManager modules;
    private static KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        modules.load();

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pikachuclient.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.pikachuclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                client.setScreen(new ClickGuiScreen());
            }
            if (client.player != null) {
                modules.tick(client);
            }
        });

        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) {
                return;
            }
            modules.renderHud(context, mc);
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient && entity instanceof LivingEntity living) {
                TargetEspModule esp = modules.get(TargetEspModule.class);
                if (esp != null) {
                    esp.setLastHit(living);
                }
            }
            return ActionResult.PASS;
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
            if (modules == null) {
                return;
            }
            TargetEspModule esp = modules.get(TargetEspModule.class);
            if (esp != null && esp.isEnabled()) {
                esp.render(context);
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> modules.save());
    }
}
