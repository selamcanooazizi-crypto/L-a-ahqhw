package com.pikachuclient.module.hud;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;

public class KeystrokesModule extends Module {
    public final ColorSetting color = add(new ColorSetting("Color", 0xFFFFFF));

    public KeystrokesModule() {
        super("Keystrokes", "Shows WASD and space keys.", Category.HUD);
    }

    @Override
    public int renderHud(DrawContext context, MinecraftClient mc, int y) {
        int size = 20;
        int gap = 2;
        int baseX = 6;
        int baseY = mc.getWindow().getScaledHeight() - (size * 3 + gap * 3 + 30);

        key(context, mc, mc.options.forwardKey, "W", baseX + size + gap, baseY, size);
        key(context, mc, mc.options.leftKey, "A", baseX, baseY + size + gap, size);
        key(context, mc, mc.options.backKey, "S", baseX + size + gap, baseY + size + gap, size);
        key(context, mc, mc.options.rightKey, "D", baseX + (size + gap) * 2, baseY + size + gap, size);
        key(context, mc, mc.options.jumpKey, "_", baseX, baseY + (size + gap) * 2, size * 3 + gap * 2, size - 6);
        return y;
    }

    private void key(DrawContext context, MinecraftClient mc, KeyBinding key, String label, int x, int y, int size) {
        key(context, mc, key, label, x, y, size, size);
    }

    private void key(DrawContext context, MinecraftClient mc, KeyBinding key, String label, int x, int y, int w, int h) {
        boolean down = key.isPressed();
        context.fill(x, y, x + w, y + h, down ? color.argb(0xCC) : 0x88000000);
        int tw = mc.textRenderer.getWidth(label);
        context.drawText(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, down ? 0xFF000000 : color.argb(), false);
    }
}
